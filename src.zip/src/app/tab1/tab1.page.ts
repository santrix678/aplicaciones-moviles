import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NativeFeaturesService } from '../services/native-features';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule,
    FormsModule
  ],
})
export class Tab1Page {

  fotoPrenda: string | null = null;
  coordenadas: { lat: number; lng: number } | null = null;
  direccionManual: string = '';

  // IP local de tu laptop en la red Wi-Fi
  private backendUrl = 'http://192.168.100.94:5001/api/pedidos';
  private backendBackupUrl = 'http://192.168.100.94:5000/api/pedidos';

  constructor(
    private authService: AuthService,
    private router: Router,
    private nativeService: NativeFeaturesService,
    private http: HttpClient
  ) {}

  async capturarFoto() {
    try {
      const foto = await this.nativeService.tomarFotoPrenda();
      if (foto) this.fotoPrenda = foto;
    } catch (e) {
      console.log('Error o cancelación al tomar foto', e);
    }
  }

  async capturarUbicacion() {
    try {
      const coords = await this.nativeService.obtenerUbicacionRecogida();
      if (coords) this.coordenadas = coords;
    } catch (e) {
      this.coordenadas = { lat: -0.2309, lng: -78.5211 };
    }
  }

  enviarOrden() {
    const payload = {
      direccion: this.direccionManual || 'Av. Amazonas y Colón',
      latitud: this.coordenadas ? this.coordenadas.lat : -0.2309,
      longitud: this.coordenadas ? this.coordenadas.lng : -78.5211,
      foto_prenda: this.fotoPrenda || 'foto_registrada.jpg'
    };

    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    // Petición a la IP de la laptop en el puerto 5001
    this.http.post(this.backendUrl, payload, { headers }).subscribe({
      next: (res: any) => {
        alert(res.mensaje || '¡Orden registrada exitosamente en Santrix!');
        this.limpiarFormulario();
      },
      error: (err: any) => {
        console.error('Error conectando al puerto 5001, intentando puerto 5000...', err);
        // Respaldo en puerto 5000
        this.http.post(this.backendBackupUrl, payload, { headers }).subscribe({
          next: (res: any) => {
            alert(res.mensaje || '¡Orden registrada exitosamente en Santrix!');
            this.limpiarFormulario();
          },
          error: (err2: any) => {
            console.error('Error final de conexión:', err2);
            alert('Error al conectar con el servidor backend. Asegúrate de que la laptop y el celular estén en la misma Wi-Fi y Flask esté activo.');
          }
        });
      }
    });
  }

  private limpiarFormulario() {
    this.fotoPrenda = null;
    this.coordenadas = null;
    this.direccionManual = '';
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

}