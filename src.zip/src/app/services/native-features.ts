import { Injectable } from '@angular/core';
import { Camera, CameraResultType, CameraSource, PermissionStatus as CameraPermission } from '@capacitor/camera';
import { Geolocation, Position } from '@capacitor/geolocation';
import { NativeSettings, AndroidSettings, IOSSettings } from 'capacitor-native-settings';

@Injectable({
  providedIn: 'root'
})
export class NativeFeaturesService {

  constructor() {}

  // --- CÁMARA ---
  async tomarFotoPrenda(): Promise<string | null> {
    try {
      const status: CameraPermission = await Camera.checkPermissions();

      if (status.camera === 'denied') {
        const request = await Camera.requestPermissions({ permissions: ['camera'] });
        if (request.camera === 'denied') {
          this.mostrarAlertaAjustes('Permiso de Cámara Denegado', 'Para fotografiar las prendas debes activar la cámara en los ajustes del sistema.');
          return null;
        }
      }

      const image = await Camera.getPhoto({
        quality: 80,
        allowEditing: false,
        resultType: CameraResultType.Base64,
        source: CameraSource.Camera
      });
      return `data:image/jpeg;base64,${image.base64String}`;
    } catch (error) {
      console.warn('Captura cancelada o no disponible:', error);
      return null;
    }
  }

  // --- GEOLOCALIZACIÓN ---
  async obtenerUbicacionRecogida(): Promise<{ lat: number; lng: number } | null> {
    try {
      const perm = await Geolocation.checkPermissions();

      if (perm.location === 'denied') {
        const req = await Geolocation.requestPermissions();
        if (req.location === 'denied') {
          this.mostrarAlertaAjustes('Permiso de Ubicación Denegado', 'Para ubicar tu domicilio automáticamente habilita la ubicación en ajustes.');
          return null;
        }
      }

      const coordinates: Position = await Geolocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000
      });

      return {
        lat: coordinates.coords.latitude,
        lng: coordinates.coords.longitude
      };
    } catch (e) {
      console.error('Error al obtener ubicación:', e);
      return null;
    }
  }

  // Redirección a Ajustes del Sistema
  async abrirAjustesSistema() {
    await NativeSettings.open({
      optionAndroid: AndroidSettings.ApplicationDetails,
      optionIOS: IOSSettings.App
    });
  }

  private mostrarAlertaAjustes(titulo: string, mensaje: string) {
    if (confirm(`${titulo}\n${mensaje}\n\n¿Deseas abrir los Ajustes ahora?`)) {
      this.abrirAjustesSistema();
    }
  }
}
